. ./kafka.inc
$pathroot/bin/kafka-topics.sh --zookeeper localhost:2181 --delete --topic $1
