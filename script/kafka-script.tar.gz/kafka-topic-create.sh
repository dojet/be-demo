. ./kafka.inc
$pathroot/bin/kafka-topics.sh --zookeeper localhost:2181 --create --topic $1 --replication-factor $2 --partitions $3
